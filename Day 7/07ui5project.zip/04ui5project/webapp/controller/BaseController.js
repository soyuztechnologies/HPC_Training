sap.ui.define([
    'sap/ui/core/mvc/Controller'
], function(Controller) {
    'use strict';
    return Controller.extend("tom.controller.BaseController",{
        //These variables are reusable across all controllers
        x: "some reusable text",
        oCore: sap.ui.getCore()
    });
});