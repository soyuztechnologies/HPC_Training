//controller is a class - JS - Module
//Any .js file in SAPUI5 starts with sap.ui.define - Scaffolding syntax, AMD like syntax
//AMD = Asynchronous Module loading
//if you see a class in UI5, replace . with / it becomes module name
//sap.m.Button ==> sap/m/Button
sap.ui.define(
    ['tom/controller/BaseController',
     'tom/model/models',
    'tom/util/lifeSaver'],
    function(Controller, models, lifeSaver){
        //We use extend keyword in JS to confirm inheritence
        return Controller.extend("tom.controller.Main",{
            name: "",
            //in the view if we want to access global variable we use a dot
            //.spiderman
            spiderman: lifeSaver,
            onInit: function(){
                //When the controller object is created
                this.name = "Anubhav";
                //model is object
                var oModel = models.createJSONModel("model/mockdata/sampledata.json");
                //a model w/o name is called default model
                this.oCore.setModel(oModel);

                var oModel2 = models.createJSONModel("model/mockdata/data2.json");
                //named model
                this.oCore.setModel(oModel2, "cartoon");

                //var oXMLModel = models.createXMLModel();
                //this.oCore.setModel(oXMLModel);

                var oResource = models.createResourceModel();
                this.oCore.setModel(oResource,"i18n");

                //get table object
                var oTable = this.getView().byId("idTable");
                //bind aggregation dynamically
                oTable.bindAggregation("rows",{
                    path: '/empTable'
                });

                //Runtime binding syntax
                //this.getView().byId("idSal").bindValue("/empStr/salary");
                //this.getView().byId("idCurr").bindProperty("value", "/empStr/currency");

            },
            onSelectRow: function (oEvent) {
                //Eveny Event in UI5 comes with a Event Object which is FREE
                //That event object carries lots of infor. about event
                //e.g. RowSelect event comes with sIndex, Memory Data
                console.log(oEvent.getParameter("rowContext").getPath());
                var sElementKaPath = oEvent.getParameter("rowContext").getPath();

                var oSimpleForm = this.getView().byId("idSimpleForm");
                //Ship the element address to the parent of all my input fields
                //ElementBinding
                oSimpleForm.bindElement(sElementKaPath);
                //alert("Jolesho!");
            },
            onPrint: function (params) {
                var oModel = this.oCore.getModel();
                //Step 2: change data into the model
                //oModel.setProperty("/empStr/empName", "Spiderman");
                var jsonData = oModel.getProperty("/");
                console.log(jsonData);
            },
            onMagic: function () {

                //Step 1: get the model object
                var oModel = this.oCore.getModel();
                //Step 2: change data into the model
                //oModel.setProperty("/empStr/empName", "Spiderman");
                oModel.setProperty("/empStr", {
                    "empId": 1505,
                    "empName":"Shobit Verma",
                    "salary": 9885,
                    "currency": "USD"
                });
                //GODEN RULE - Always play with data even on UI with model
                //this.getView().byId("idEmpName").setValue("Spiderman");
                
                // var oModel = this.oCore.getModel();
                // oModel.getProperty("/")
                // oModel.setProperty("/empStr/empName", "Spiderman")
                // oModel.getProperty("/")
                // oModel.getProperty("/")
                
            },
            onFlip: function(){
                var oModel = this.oCore.getModel();
                var sStatus = oModel.getProperty("/empStr/mStatus");
                if(sStatus === true){
                    oModel.setProperty("/empStr/mStatus", false);
                }else{
                    oModel.setProperty("/empStr/mStatus", true);
                }
                
            },
            onClick: function(){
                alert("Welcome to the world of UI5 titans " + this.name);
                //Access view object inside controller
                var oView = this.getView();

                //Ex2
                var sUser = oView.byId("idUsr").getValue();
                var sPwd =  oView.byId("idPwd").getValue();
                if(sUser === sPwd){
                    alert("login worked!");
                }


                //Ex1 - Rules of controller
                //Access the control object in the controller
                //var oBtn = oView.byId("idBtn");
                //WRONG - document.getElementById("idBtn")
                //oBtn.setText("Bhalo");
                //another way is to use application object to get control object
                //sap.ui.getCore().byId("idAnubhav--idBtn")
            }
        });
    }
);