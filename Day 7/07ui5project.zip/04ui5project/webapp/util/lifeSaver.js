sap.ui.define([
    
], function() {
    'use strict';
    return {
        convertToBigName: function (input) {
            if(input){
                return input.toUpperCase();
            }
        }
    }
});