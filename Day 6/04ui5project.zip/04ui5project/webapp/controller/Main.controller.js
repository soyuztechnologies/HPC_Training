//controller is a class - JS - Module
//Any .js file in SAPUI5 starts with sap.ui.define - Scaffolding syntax, AMD like syntax
//AMD = Asynchronous Module loading
//if you see a class in UI5, replace . with / it becomes module name
//sap.m.Button ==> sap/m/Button
sap.ui.define(
    ['sap/ui/core/mvc/Controller',
     'tom/model/models'],
    function(Controller, models){
        //We use extend keyword in JS to confirm inheritence
        return Controller.extend("tom.controller.Main",{
            name: "",
            onInit: function(){
                //When the controller object is created
                this.name = "Anubhav";
                //model is object
                var oModel = models.createJSONModel("model/mockdata/sampledata.json");
                sap.ui.getCore().setModel(oModel);

                //Runtime binding syntax
                this.getView().byId("idSal").bindValue("/empStr/salary");
                this.getView().byId("idCurr").bindProperty("value", "/empStr/currency");

            },
            onPrint: function (params) {
                var oModel = sap.ui.getCore().getModel();
                //Step 2: change data into the model
                //oModel.setProperty("/empStr/empName", "Spiderman");
                var jsonData = oModel.getProperty("/empStr");
                console.log(jsonData);
            },
            onMagic: function () {

                //Step 1: get the model object
                var oModel = sap.ui.getCore().getModel();
                //Step 2: change data into the model
                //oModel.setProperty("/empStr/empName", "Spiderman");
                oModel.setProperty("/empStr", {
                    "empId": 1505,
                    "empName":"Shobit Verma",
                    "salary": 9885,
                    "currency": "USD"
                });
                //GODEN RULE - Always play with data even on UI with model
                //this.getView().byId("idEmpName").setValue("Spiderman");
                
                // var oModel = sap.ui.getCore().getModel();
                // oModel.getProperty("/")
                // oModel.setProperty("/empStr/empName", "Spiderman")
                // oModel.getProperty("/")
                // oModel.getProperty("/")
                
            },
            onClick: function(){
                alert("Welcome to the world of UI5 titans " + this.name);
                //Access view object inside controller
                var oView = this.getView();

                //Ex2
                var sUser = oView.byId("idUsr").getValue();
                var sPwd =  oView.byId("idPwd").getValue();
                if(sUser === sPwd){
                    alert("login worked!");
                }


                //Ex1 - Rules of controller
                //Access the control object in the controller
                //var oBtn = oView.byId("idBtn");
                //WRONG - document.getElementById("idBtn")
                //oBtn.setText("Bhalo");
                //another way is to use application object to get control object
                //sap.ui.getCore().byId("idAnubhav--idBtn")
            }
        });
    }
);