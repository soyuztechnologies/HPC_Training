sap.ui.define([
    "sap/ui/model/json/JSONModel"
], function(JSONModel) {
    'use strict';
    return {
        createJSONModel: function(sFilePath){
                // Step 1: Create a brand-new object of the Model
                // To Create JSON Model - var oModel = sap.ui.model.json.JOSNModel()
                var oModel = new JSONModel();

                // Step 2: Set or Load the data in the Model
                // oModel.setData({});
                // oModel.loadData(filePath);
                oModel.loadData(sFilePath);

                return oModel;
                // Step 3: Make the model aware to the application/view
                // sap.ui.getCore().setModel(oModel);
                // this.getView().setModel(oModel);
                //sap.ui.getCore().setModel(oModel);
        }
    }
});