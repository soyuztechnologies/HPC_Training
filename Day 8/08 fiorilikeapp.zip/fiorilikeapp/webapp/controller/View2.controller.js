sap.ui.define([
    'hpc/sd/sales/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("hpc.sd.sales.controller.View2",{
        onBack: function(){
            //Step 1: Get The Container Control object here
            var oAppCon = this.getView().getParent();
            //Step 2: Container will navigate to next view
            oAppCon.to("idView1");
        }
    });
});