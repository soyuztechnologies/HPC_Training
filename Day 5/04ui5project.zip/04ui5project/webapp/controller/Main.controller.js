//controller is a class - JS - Module
//Any .js file in SAPUI5 starts with sap.ui.define - Scaffolding syntax, AMD like syntax
//AMD = Asynchronous Module loading
//if you see a class in UI5, replace . with / it becomes module name
//sap.m.Button ==> sap/m/Button
sap.ui.define(
    ['sap/ui/core/mvc/Controller'],
    function(Controller){
        //We use extend keyword in JS to confirm inheritence
        return Controller.extend("tom.controller.Main",{
            name: "",
            onInit: function(){
                //When the controller object is created
                this.name = "Anubhav";
            },
            onClick: function(){
                alert("Welcome to the world of UI5 titans " + this.name);
                //Access view object inside controller
                var oView = this.getView();

                //Ex2
                var sUser = oView.byId("idUsr").getValue();
                var sPwd =  oView.byId("idPwd").getValue();
                if(sUser === sPwd){
                    alert("login worked!");
                }


                //Ex1 - Rules of controller
                //Access the control object in the controller
                //var oBtn = oView.byId("idBtn");
                //WRONG - document.getElementById("idBtn")
                //oBtn.setText("Bhalo");
                //another way is to use application object to get control object
                //sap.ui.getCore().byId("idAnubhav--idBtn")
            }
        });
    }
);