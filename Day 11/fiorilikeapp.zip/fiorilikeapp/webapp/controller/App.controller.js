sap.ui.define([
    'hpc/sd/sales/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("hpc.sd.sales.controller.App",{

    });
});